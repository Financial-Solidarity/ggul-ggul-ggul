declare module '@types' {
  export interface WalletDTO {
    address: string;
    privateKey: string;
  }
}
