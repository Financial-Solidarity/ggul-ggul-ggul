declare module '@types' {
  export interface UserSignUpForm {
    email: string;
    nickname: string;
    password: string;
  }
}
