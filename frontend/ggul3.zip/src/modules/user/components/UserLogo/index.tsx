export const UserLogo = () => {
  return (
    <h1 className="mb-10 text-center text-6xl font-black text-primary">
      GGUL3
    </h1>
  );
};
