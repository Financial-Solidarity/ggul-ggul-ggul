import { BottomSheetExample } from '@/modules/common/components/BottomSheetExample/BottomSheetExample';

export default function Temp() {
  return (
    <h1>
      <div>
        <BottomSheetExample />
      </div>
    </h1>
  );
}
