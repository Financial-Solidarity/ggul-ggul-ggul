export const PrizeHistoryPage = () => {
  return <div>응모 내역 페이지 - 작업 예정</div>;
};
