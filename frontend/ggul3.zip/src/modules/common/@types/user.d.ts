declare module '@types' {
  export interface UserDTO {
    userId: string;
    username: string;
    nickname: string;
    profileImg: string;
  }
}
