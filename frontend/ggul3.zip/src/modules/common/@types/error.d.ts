declare module '@types' {
  export interface ErrorDTO {
    status: string;
    message: string;
  }
}
