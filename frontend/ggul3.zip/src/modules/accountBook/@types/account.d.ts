declare module '@types' {
  export interface Account {
    id: number;
    name: string;
    accountNo: string;
  }
}
